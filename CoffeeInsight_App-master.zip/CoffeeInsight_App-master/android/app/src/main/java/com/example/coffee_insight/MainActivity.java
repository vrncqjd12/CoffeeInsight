package com.example.coffee_insight;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
